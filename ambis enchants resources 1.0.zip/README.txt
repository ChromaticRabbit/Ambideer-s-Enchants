This pack was created as a fun personal challenge, to make a new resource pack without drawing
any new pixels. All blocks and items are retextured only by manipulating vanilla textures through
the use of layer blending, layer effects, or recoloring.
